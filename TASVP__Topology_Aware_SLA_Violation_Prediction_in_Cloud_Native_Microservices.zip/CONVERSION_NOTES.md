# IEEE Access conversion — TAM-SLAVP

- Source: supplied ZIP containing `main.tex`, `bibliography.bib`, and 19 figure assets.
- Target: official IEEE Access LaTeX template dated 2026-05-13, downloaded from IEEE Access.
- Retained: scientific prose, title wording, abstract, numerical results, tables, equations, citation keys, bibliography, and supplied figures.
- Formatting adapted: `ieeeaccess` class, IEEE Access title/author/affiliation/correspondence block, abstract/keywords placement, two-column page layout, and one oversized illustration width.
- The original author-list order and contact addresses have been retained. No publication date or DOI was invented.
- The title's `TASVP` acronym was preserved exactly as supplied even though the abstract uses `TAM-SLAVP`; verify this discrepancy before submission.
- Compilation was attempted, but this environment lacks the LaTeX `algorithm.sty` package. The PDF is **not yet verified**. Compile on a full TeX Live or Overleaf setup with the packages `algorithm`, `algorithmicx`, `subcaption`, and other standard packages enabled.
- Source assets from the official IEEE Access template (`ieeeaccess.cls`, `IEEEtran.cls`, font assets and support graphics) are included for portability.

To compile from inside this folder on a complete LaTeX installation:

```
latexmk -pdf main.tex
```

The source ZIP has not been altered; this is a separately converted copy.
